# 1v1sim
a fighting game that looks good and is fun
